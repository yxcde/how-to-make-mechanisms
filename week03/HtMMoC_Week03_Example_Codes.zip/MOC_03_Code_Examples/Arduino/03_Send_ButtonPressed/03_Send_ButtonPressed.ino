const int buttonPin = 8;
bool lastState = LOW;

void setup() {
  pinMode(buttonPin, INPUT_PULLUP);
  Serial.begin(9600);
}

void loop() {
  bool currentState = digitalRead(buttonPin);
  if (lastState == HIGH && currentState == LOW) {
    Serial.println("BUTTON_PRESSED"); // send the exact message expected by the python script
  }
  lastState = currentState;
  delay(50); // for debouncing 
}