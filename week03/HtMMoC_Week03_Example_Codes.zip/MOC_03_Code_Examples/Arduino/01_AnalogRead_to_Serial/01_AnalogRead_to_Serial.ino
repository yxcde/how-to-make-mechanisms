int potPin = 26;
int potPin2 = 27;

bool debug = false;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
}

void loop() {
  // put your main code here, to run repeatedly:
  int value = analogRead(potPin);
  int value2 = analogRead(potPin2);

  if (debug == true) {
    Serial.print("Value is: ");
    Serial.print(value);
    Serial.print(" | Value2 is: ");
    Serial.println(value2);
  } else {
    Serial.println(value);
  }
  delay(10);
}
