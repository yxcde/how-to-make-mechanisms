int potPin1 = A0;
int potPin2 = A1;
int buttonPin = 8;

int buttonState = 0;
int potValue1 = 0;
int potValue2 = 0;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  pinMode(buttonPin, INPUT);
}

void loop() {
  potValue1 = analogRead(potPin1);
  potValue2 = analogRead(potPin2);
  buttonState = digitalRead(buttonPin);

  Serial.print(potValue1);
  Serial.print(",");
  Serial.print(potValue2);
  Serial.print(",");
  Serial.println(buttonState);
  //Serial.print('\n');
}
