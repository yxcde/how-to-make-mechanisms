// Example 3A: Using bool != bool to toggle state on button press

int buttonPin = 7;
int ledPin = 8;
bool ledState = false;
bool lastButtonState = HIGH;

void setup() {
  pinMode(buttonPin, INPUT);
  pinMode(ledPin, OUTPUT);
}

void loop() {
  bool buttonState = digitalRead(buttonPin);

  // Detect button press transition
  if (buttonState == false && lastButtonState == true) {
    // Toggle LED state
    ledState = !ledState;       // This means: ledState = ledState != true;
    digitalWrite(ledPin, ledState);
    delay(100); // Debounce delay
  }

  lastButtonState = buttonState;
}