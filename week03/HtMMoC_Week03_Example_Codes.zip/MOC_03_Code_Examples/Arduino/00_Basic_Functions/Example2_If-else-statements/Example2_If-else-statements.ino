// Example 2: If-Else for decision making

int buttonPin = 7;
int ledPin = 8;
int buttonState = 0;

void setup() {
  pinMode(buttonPin, INPUT); 
  pinMode(ledPin, OUTPUT);
}

void loop() {
  buttonState = digitalRead(buttonPin);

  if (buttonState == HIGH) {   // Button pressed
    digitalWrite(ledPin, HIGH);
  } else {                     // Button not pressed
    digitalWrite(ledPin, LOW);
  }
}