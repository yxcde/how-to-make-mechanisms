// Example 4A: Button Debouncing with external pull-down resistor
//
// Wiring:
// - One side of the button → pin 2
// - Other side of the button → 5V
// - 10kΩ resistor from pin 2 → GND
// - LED (with 220Ω resistor) → pin 3 → GND

int buttonPin = 7;
int ledPin = 8;

bool ledState = false;          // current LED state
bool lastButtonState = false;     // last stable reading
unsigned long lastDebounceTime = 0;
unsigned long debounceDelay = 50;  // 50 ms debounce time window

void setup() {
  pinMode(buttonPin, INPUT);   
  pinMode(ledPin, OUTPUT);
}

void loop() {
  int reading = digitalRead(buttonPin);

  // If the button input changed, reset the debounce timer
  if (reading != lastButtonState) {
    lastDebounceTime = millis();
  }

  // Check if the input has been stable longer than debounceDelay
  if ((millis() - lastDebounceTime) > debounceDelay) {
    // If the stable state is HIGH, toggle the LED
    if (reading == HIGH) {
      ledState = !ledState;
      digitalWrite(ledPin, ledState);
    }
  }

  // Update lastButtonState for the next loop cycle
  lastButtonState = reading;
}