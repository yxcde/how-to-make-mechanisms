// Example 1: Blinking 1 LED 

int led1 = 2; // LED pin

void setup() {
  pinMode(led1, OUTPUT); 
}

void loop() {
  digitalWrite(led1, HIGH);
  delay(150);
  digitalWrite(led1, LOW);
  delay(150);

}
