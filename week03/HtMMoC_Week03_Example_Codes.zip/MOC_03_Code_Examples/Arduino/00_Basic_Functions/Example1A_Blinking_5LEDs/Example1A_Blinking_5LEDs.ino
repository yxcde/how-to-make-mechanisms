// Example 1A: Blinking 5 LEDs in sequence, the manual way
// Demonstrates what the code looks like before learning about loops.

int led1 = 18;
int led2 = 19;
int led3 = 20;
int led4 = 21;
int led5 = 22;

void setup() {
  pinMode(led1, OUTPUT);
  pinMode(led2, OUTPUT);
  pinMode(led3, OUTPUT);
  pinMode(led4, OUTPUT);
  pinMode(led5, OUTPUT);
}

void loop() {
  // Turn each LED on and off manually — lots of repetition!
  digitalWrite(led1, HIGH);
  delay(150);
  digitalWrite(led1, LOW);

  digitalWrite(led2, HIGH);
  delay(150);
  digitalWrite(led2, LOW);

  digitalWrite(led3, HIGH);
  delay(150);
  digitalWrite(led3, LOW);

  digitalWrite(led4, HIGH);
  delay(150);
  digitalWrite(led4, LOW);

  digitalWrite(led5, HIGH);
  delay(150);
  digitalWrite(led5, LOW);
}