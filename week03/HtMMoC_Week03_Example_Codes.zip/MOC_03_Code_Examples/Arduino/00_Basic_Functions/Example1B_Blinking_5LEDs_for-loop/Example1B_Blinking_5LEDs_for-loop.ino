// Example 1B: Using a for-loop to blink 5 LEDs in sequence
//
int ledPins[] = { 18, 19, 20, 21, 22 };  // LED pins
int ledCount = 5;

void setup() {
  // Set all LED pins as outputs

  for (int i = 0; i < ledCount; i++) {
    pinMode(ledPins[i], OUTPUT);
  }
}

void loop() {
  // Turn each LED on and off one after another
  for (int i = 0; i < ledCount; i++) {
    digitalWrite(ledPins[i], HIGH);
    delay(100);
    digitalWrite(ledPins[i], LOW);
  }
}