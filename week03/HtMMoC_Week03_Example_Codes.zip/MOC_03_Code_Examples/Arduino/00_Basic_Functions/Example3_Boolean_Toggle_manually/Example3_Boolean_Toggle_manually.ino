// Example 3: Toggling an LED manually without using boolean logic
// (written as if we didn't know about ledState = !ledState;)

int buttonPin = 7;
int ledPin = 8;
bool ledState = false;            // 0/LOW means OFF, 1/HIGH means ON
int lastButtonState = HIGH;    // remember the last button reading

void setup() {
  pinMode(buttonPin, INPUT);
  pinMode(ledPin, OUTPUT);
}

void loop() {
  int buttonState = digitalRead(buttonPin);

  // Check if button is pressed (transition from HIGH to LOW)
  if (buttonState == LOW && lastButtonState == true) {

    // If LED is currently off, turn it on
    if (ledState == false) {
      ledState = true;
      digitalWrite(ledPin, HIGH);
    }
    // Otherwise, if LED is on, turn it off
    else if (ledState == true) {
      ledState = false;
      digitalWrite(ledPin, LOW);
    }

    delay(200); // debounce delay
  }

  lastButtonState = buttonState;
}
