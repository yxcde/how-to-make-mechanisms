// Example of controlling multiple values via Serial from an Arduino

import processing.serial.*;

int val1 = 0;   // variable to hold one value from the Serial connection
int val2 = 0;
int val3 = 0;

Serial myPort;   // Serial object
String[] serialData; // Array to store the Serial message

void setup() {
  size(550, 550);
  printArray(Serial.list()); // list all available Serial ports
  myPort = new Serial(this, Serial.list()[7], 9600); // choose a port 
  myPort.bufferUntil('\n'); // listen to the newline event on the Serial port
}

void draw() {
  background(0);
  noStroke();
  fill(255);
  ellipse(width/2, height/2, val1, val1); // apply the value from sensor 1 to the size of the ellipse
  fill(170, 100);
  ellipse(width/2, height/2, val2, val2); // apply the value from sensor 2 to the size of the ellipse
}

void serialEvent(Serial myPort) {
  String inString = myPort.readStringUntil('\n');
  if (inString != null) {
    inString = trim(inString);           // trim the string to only leave the values
    serialData = split(inString, ',');   // split the string whenever there is a comma
    updateValues();                      // do the saving of the values in a separate void just for readability
  }
}

void updateValues() {
  if (serialData.length > 0) val1 = int(serialData[0]);
  if (serialData.length > 1) val2 = int(serialData[1]);
  if (serialData.length > 2) val3 = int(serialData[2]);
}
