// Example for controlling one value via Serial communication from an Arduino 

import processing.serial.*;

Serial myPort;   // Serial object
int sensorValue; // Variable to store the sensor input 

void setup() {
  size(800, 800);
  printArray(Serial.list());
  myPort = new Serial(this, "/dev/tty.usbmodem142101", 9600);
  myPort.bufferUntil('\n');
}

void draw() {
  background(0);
  float mapped = map(sensorValue, 5, 100, 0, width); // additional mapping 
  ellipse(width/2, height/2, mapped, mapped);
}

void serialEvent(Serial myPort) {
  String inString = myPort.readStringUntil('\n');
  if (inString != null) {
    sensorValue = int(trim(inString));
  }
}
