// How to Make Mechanisms of Control Class at UdK Berlin Summer Semester 2026 - Karsten Schuhl

// simple sketch to send position target data 
// to an arduino to control a stepper motor

import processing.serial.*;

Serial myPort;

void setup() {
  // configure to match the serial port you are using 
  // replace Serial.list[7] with your port name - check your spelling
  myPort = new Serial(this, Serial.list()[7], 9600);
}

void draw() {
  // no visual interface this time
  background(0);
}

void keyPressed() {
  // send data by either pressing the a, d or s key
  if (key == 'a') {
    myPort.write("M:0\n");
    println("sent an 'a'");
  } else if (key == 'd') {
    myPort.write("M:20\n");
    println("sent a 'd'");
  } else if (key == 's') {
    myPort.write("S\n");
    println("sent a 's'");
  }
}
