// How to Make Mechanisms of Control - UdK Berlin Winter Semester 2025/26 - Karsten Schuhl
// Adapted for Raspberry Pi Pico 2W - Threshold for sensor input to keep Servo from wiggling

// TASK: replace the potentiometer with another sensor (distance or similar) and 
// calibrate the threshold and mapping so that they work well

#include <Servo.h> 

Servo myServo;

// Pin assignments for Raspberry Pi Pico 2W
const int sensorPin = 26; // A0 on the Pico
const int servoPin = 15;

// Variables for checks and functions
const int threshold = 2;          // Minimum change in degrees to trigger motion
const int maxAngle = 180;         // Maximum angle for a standard servo
int lastTargetAngle = -999;       // Store last accepted angle (start at -999 to guarantee first move)

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);       // Pico's 12-bit ADC resolution
  
  myServo.attach(servoPin); 
}

void loop() {
  int sensorValue = analogRead(sensorPin); // read the sensor 
  
  // Map the 12-bit sensor values (0-4095) to servo angles (0-maxAngle)
  int targetAngle = map(sensorValue, 0, 4095, 0, maxAngle); 

  // Check if the difference between the new targetAngle and the last one exceeds the threshold
  if (abs(targetAngle - lastTargetAngle) >= threshold) {
    myServo.write(targetAngle);
    lastTargetAngle = targetAngle;
    
    // Printing only when it passes the threshold makes it easy to see the logic working
    Serial.print("Moving to angle: ");
    Serial.println(targetAngle);
  }
  
  delay(15); // Short delay for stability
}