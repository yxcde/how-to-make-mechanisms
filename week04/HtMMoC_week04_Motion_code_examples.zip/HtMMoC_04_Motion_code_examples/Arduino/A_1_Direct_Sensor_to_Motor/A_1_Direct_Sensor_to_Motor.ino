// How to Make Mechanisms of Control - UdK Berlin Summer Semester 2026 - Karsten Schuhl
// Adapted for Raspberry Pi Pico 2W - Potentiometer to Servo Motor Position

#include <Servo.h>

Servo myServo;

// Pin assignments for Raspberry Pi Pico 2W
const int servoPin = 15; // You can use almost any GP pin for PWM on the Pico
const int potPin = 26;   // A0 on the Pico corresponds to GP26

void setup() {
  // 115200 is the standard baud rate for Pico over USB
  Serial.begin(115200); 
  
  // The Pico has a higher resolution 12-bit ADC (0-4095) 
  // compared to a standard Arduino's 10-bit ADC (0-1023).
  analogReadResolution(12);
  
  myServo.attach(servoPin);
}

void loop() {
  // Read the potentiometer value (now ranging from 0 to 4095)
  int sensorValue = analogRead(potPin);
  
  Serial.println(sensorValue);
  
  // Map the 12-bit sensor value to a standard servo angle (0 to 180 degrees)
  int targetAngle = map(sensorValue, 0, 4095, 0, 180); 

  // Command the servo to move to the target angle
  myServo.write(targetAngle); 
  
  // A small delay gives the servo physical time to move 
  // and prevents overwhelming the serial monitor
  delay(15); 
}