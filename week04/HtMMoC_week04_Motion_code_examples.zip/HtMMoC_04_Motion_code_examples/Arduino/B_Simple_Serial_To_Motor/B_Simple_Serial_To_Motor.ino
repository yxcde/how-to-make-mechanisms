// How to Make Mechanisms of Control - UdK Berlin Summer Semester 2026 - Karsten Schuhl
// Adapted for Raspberry Pi Pico 2W - Serial Commands to Servo

// TASK: Implement a second command to stop the motor.
// -> Implemented 'S' to detach/disable the servo.

#include <Servo.h>

Servo myServo;

// Pin assignments
const int servoPin = 15;
// The Pico 2W has an onboard LED we can use, mapped to the macro LED_BUILTIN
const int ledPin = LED_BUILTIN; 

String inputString = ""; // to hold the incoming string from the serial connection

void setup() {
  Serial.begin(115200);
  pinMode(ledPin, OUTPUT);
  
  // Start with the servo attached
  myServo.attach(servoPin);
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      handleCommand(inputString);
      inputString = "";
    } else {
      inputString += c;
    }
  }
}

void handleCommand(String cmd) {
  // --- MOVE COMMAND ---
  // Expected format: M:90 (Moves to 90 degrees)
  if (cmd.startsWith("M:")) {   
    // Convert the data that follows after "M:" to an integer
    int targetAngle = cmd.substring(2).toInt(); 
    
    // Constrain the angle between 0 and 180 to protect the servo
    targetAngle = constrain(targetAngle, 0, 180);

    digitalWrite(ledPin, HIGH); 
    
    // If the servo was previously stopped (detached), re-attach it
    if (!myServo.attached()) {
      myServo.attach(servoPin);
    }
    
    myServo.write(targetAngle);
    
    Serial.print("Acknowledged Motion to angle: ");      
    Serial.println(targetAngle);
    
    // Quick delay just so you can visibly see the LED flash on the Pico
    delay(50);
    digitalWrite(ledPin, LOW); 
  } 
  
  // --- STOP COMMAND (TASK COMPLETED) ---
  // Expected format: S (Stops holding position)
  else if (cmd.startsWith("S")) {
    digitalWrite(ledPin, HIGH); 
    
    // Detaching removes the PWM signal. The servo will stop moving 
    // and lose its holding torque (you can move it freely by hand).
    myServo.detach();
    
    Serial.println("Acknowledged Stop (Servo disabled)");
    
    delay(50);
    digitalWrite(ledPin, LOW);
  } 
  
  // --- ERROR HANDLING ---
  else {
    Serial.println("ERR:UnknownCmd"); 
  }
}