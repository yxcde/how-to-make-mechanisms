// How to Make Mechanisms of Control - UdK Berlin Summer Semester 2026 - Karsten Schuhl
// Adapted for Raspberry Pi Pico 2W - EMA Smoothing + Deadband

#include <Servo.h> 

Servo myServo;

const int sensorPin = 26; 
const int servoPin = 15;

// --- Smoothing Variables ---
// Alpha value between 0.0 (infinite delay) and 1.0 (no smoothing)
// 0.1 is usually a great starting point for noisy analog sensors
const float alpha = 0.1; 
float filteredSensorValue = 0.0; // Store as a float for precision during math

// --- Threshold Variables ---
const int threshold = 1;          // Minimum change in degrees to move
const int maxAngle = 180;         
int lastTargetAngle = -999;       

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);       
  myServo.attach(servoPin); 
  
  // Prime the filter with the first reading so it doesn't 
  // slowly ramp up from 0 when the device turns on
  filteredSensorValue = analogRead(sensorPin);
}

void loop() {
  // 1. Read the raw, noisy sensor
  int rawSensorValue = analogRead(sensorPin); 
  
  // 2. Apply the Exponential Moving Average (aka. EMA) math
  filteredSensorValue = (alpha * rawSensorValue) + ((1.0 - alpha) * filteredSensorValue);
  
  // 3. Map the SMOOTHED value to a servo angle
  // We cast the float back to an int here because map() requires integers
  int targetAngle = map((int)filteredSensorValue, 0, 4095, 0, maxAngle); 

  // 4. Apply a small deadband threshold to eliminate any residual micro-jitters
  if (abs(targetAngle - lastTargetAngle) >= threshold) {
    myServo.write(targetAngle);
    lastTargetAngle = targetAngle;
    
    Serial.print("Raw: ");
    Serial.print(rawSensorValue);
    Serial.print("\tFiltered: ");
    Serial.print((int)filteredSensorValue);
    Serial.print("\tAngle: ");
    Serial.println(targetAngle);
  }
  
  // Run the loop consistently to keep the filter mathematically accurate
  delay(15); 
}