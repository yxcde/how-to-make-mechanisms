/*
  Blink

  Turns an LED on for one second, then off for one second, repeatedly.
  
  Delay works by pausing the programm for a certain time
  This is called blocking. Check the Serial Output to see how the delay slows down 
  the operation for the counter variable which counts the amounts of programm loops the arduino has done. 
*/

int counter = 0; // variable to hold the number of programm loops the arduino has done

// the setup function runs once when you press reset or power the board
void setup() {
  // initialize digital pin LED_BUILTIN as an output.
  pinMode(LED_BUILTIN, OUTPUT);
}

// the loop function runs over and over again forever
void loop() {
  digitalWrite(LED_BUILTIN, HIGH);  // turn the LED on (HIGH is the voltage level)
  delay(1000);                      // wait for a second
  digitalWrite(LED_BUILTIN, LOW);   // turn the LED off by making the voltage LOW
  delay(1000);                      // wait for a second
}
