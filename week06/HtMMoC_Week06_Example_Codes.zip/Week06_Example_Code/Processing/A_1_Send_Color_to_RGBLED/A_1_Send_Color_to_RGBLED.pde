// Mechanisms of Control - UdK Berlin 2025 - Karsten Schuhl
// Example A_1 - Serial to RGB LED communication

// !!! Make sure you have the ControlP5 Library installed !!!

import processing.serial.*;
import controlP5.*;

Serial myPort;
ControlP5 cp5;

int r = 0;
int g = 0;
int b = 0;

void setup() {
  size(300, 300);
  println(Serial.list());
  myPort = new Serial(this, Serial.list()[7], 9600);  // Adjust port index as needed

  cp5 = new ControlP5(this);

  cp5.addSlider("r")
    .setPosition(30, 30)
    .setRange(0, 255)
    .setValue(0)
    .setColorLabel(color(255, 0, 0));

  cp5.addSlider("g")
    .setPosition(30, 70)
    .setRange(0, 255)
    .setValue(0)
    .setColorLabel(color(0, 255, 0));

  cp5.addSlider("b")
    .setPosition(30, 110)
    .setRange(0, 255)
    .setValue(0)
    .setColorLabel(color(0, 0, 255));

  cp5.addButton("SendColor")
    .setLabel("Send Color")
    .setPosition(30, 160)
    .setSize(100, 30);
}

void draw() {
  background(r, g, b);

  fill(255);
  textAlign(LEFT, CENTER);
  text("R: " + r, 160, 40);
  text("G: " + g, 160, 80);
  text("B: " + b, 160, 120);
}

void SendColor() {
  String message = r + "," + g + "," + b + "\n";
  println("Sending: " + message.trim());
  myPort.write(message);
}
