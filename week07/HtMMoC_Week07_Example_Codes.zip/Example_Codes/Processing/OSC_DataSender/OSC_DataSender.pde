// How to Make Mechanisms of Control - UdK Berlin Summer 2026 - Karsten Schuhl
/// The Diagnostic Transmitter

// install oscP5 library to use this sketch

import oscP5.*;
import netP5.*;

OscP5 oscP5;
NetAddress broadcastLocation;

void setup() {
  size(400, 400);
  frameRate(30);
  
  // Initialize oscP5. 
  // Processing needs to listen on a port itself, 12000 is a safe default.
  oscP5 = new OscP5(this, 12000);
  
  // --- THE BROADCAST TRICK ---
  // If your router IP is 192.168.1.1, sending to .255 hits every device on the network.
  // Change the "1" if your router uses a different subnet (e.g., 192.168.0.255).
  // The port (8000) MUST match what your students' Picos are listening to!
  broadcastLocation = new NetAddress("192.168.8.255", 8000);
}

void draw() {
  // A simple visual interface to show it is running
  background(30, 41, 59); // Slate dark background
  fill(241, 245, 249);
  textAlign(CENTER, CENTER);
  textSize(16);
  text("Test Control\n\nTarget: " + broadcastLocation.address() + "\nPort: 8000\n\nMove mouse horizontally to send data.", width/2, height/2);

  // Draw a visual indicator following the mouse
  fill(79, 70, 229); // Indigo highlight
  noStroke();
  ellipse(mouseX, mouseY, 30, 30);
}

// This function triggers every time you move the mouse
void mouseMoved() {
  // 1. Create a new OSC message with the address the Picos expect
  OscMessage myMessage = new OscMessage("/interaction/distance");
  
  // 2. Map the mouse X position to the 0-1023 range the Picos expect
  int simulatedSensorValue = (int) map(mouseX, 0, width, 0, 1023);
  
  // 3. Attach the integer to the message
  myMessage.add(simulatedSensorValue);
  
  // 4. Blast it over the network to all Picos
  oscP5.send(myMessage, broadcastLocation);
}
