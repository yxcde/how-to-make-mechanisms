// How to Make Mechanisms of Control - UdK Berlin Summer 2026 - Karsten Schuhl
// Example A1 - WiFi Transmitter "The Mouth"

// Please install OSC library by Adrian Freed for this code to work on your Pico 2W MCU

#include <WiFi.h>
#include <WiFiUdp.h>
#include <OSCMessage.h>

// --- NETWORK CREDENTIALS ---
const char* ssid = "GL-SFT1200-0a9"; // this needs to be the name of your network router
const char* password = "goodlife";   // this is the password for your wifi connection

// --- TARGET DESTINATION ---
// This is the IP address of the OTHER group's Pico (The Ear)
IPAddress outIp(192, 168, 8, 171); 
const unsigned int outPort = 8000; // The port the other Pico is listening to

WiFiUDP Udp;

// --- HARDWARE ---
int sensorPin = 26; // Analog input pin

void setup() {
  Serial.begin(115200);
  delay(2000); // Give the Serial monitor time to open

  // 1. Connect to the WiFi Network
  Serial.print("Connecting to WiFi: ");
  Serial.println(ssid);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  // 2. Success! Print the local IP Address
  Serial.println("");
  Serial.println("WiFi connected!");
  Serial.print("My IP address: ");
  Serial.println(WiFi.localIP()); 
}

void loop() {
  // 1. Read the physical sensor
  int sensorValue = analogRead(sensorPin);

  // 2. Create the OSC Message
  // The string "/interaction/distance" is our custom data label
  OSCMessage msg("/interaction/distance");
  
  // Add the sensor data to the message
  msg.add(sensorValue);

  // 3. Send the Message over UDP
  Udp.beginPacket(outIp, outPort);
  msg.send(Udp);
  Udp.endPacket();

  // Clear the message to free up memory
  msg.empty();

  // Wait before sending the next packet (Don't flood the network!)
  delay(20); 
}