// How to Make Mechanisms of Control - UdK Berlin Summer 2026 - Karsten Schuhl
// Example A2 - WiFi Receiver "The Ear" - Listen to an OSC message and move a servo

// Please install OSC library by Adrian Freed for this code to work on your Pico 2W MCU

#include <WiFi.h>
#include <WiFiUdp.h>
#include <OSCMessage.h>
#include <Servo.h>

// --- NETWORK CREDENTIALS ---
const char* ssid = "GL-SFT1200-0a9"; // this needs to be the name of your network router
const char* password = "goodlife";   // this is the password for your wifi connection

// --- LISTENING PORT ---
// This must match the port the Transmitter is sending to!
const unsigned int localPort = 8000; 

WiFiUDP Udp;

// --- HARDWARE ---
Servo myServo;
int servoPin = 15;

void setup() {
  Serial.begin(115200);
  myServo.attach(servoPin);
  delay(2000);

  // 1. Connect to WiFi
  Serial.print("Connecting to WiFi: ");
  Serial.println(ssid);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected!");
  Serial.print("My IP address: ");
  Serial.println(WiFi.localIP());

  // 2. Start listening for incoming UDP packets
  Udp.begin(localPort);
  Serial.printf("Now listening at IP %s, UDP port %d\\n", WiFi.localIP().toString().c_str(), localPort);
}

void loop() {
  // 1. Create an empty message to hold incoming data
  OSCMessage msg;
  int size = Udp.parsePacket();

  // 2. Check if a packet has arrived
  if (size > 0) {
    while (size--) {
      // Read the data byte by byte into our OSCMessage
      msg.fill(Udp.read());
    }
    
    // 3. If there are no errors, route the message to our custom function
    if (!msg.hasError()) {
      // If the message address is exactly "/interaction/distance", 
      // trigger the 'driveMotor' function
      msg.route("/interaction/distance", driveMotor);
    }
  }
}

// --- CUSTOM ROUTING FUNCTION ---
// This function only runs when the correct OSC message arrives
void driveMotor(OSCMessage &msg, int addrOffset) {
  // Make sure the data attached is actually an integer
  if (msg.isInt(0)) { 
    
    // Extract the integer from the message
    int sensorValue = msg.getInt(0); 
    
    // Map the incoming sensor data (0-1023) to a servo angle (0-180)
    int targetAngle = map(sensorValue, 0, 1023, 0, 180);
    
    // Move the physical motor!
    myServo.write(targetAngle);
    
    // Optional Debugging
    Serial.print("Received: ");
    Serial.print(sensorValue);
    Serial.print(" | Moving servo to: ");
    Serial.println(targetAngle);
  }
}