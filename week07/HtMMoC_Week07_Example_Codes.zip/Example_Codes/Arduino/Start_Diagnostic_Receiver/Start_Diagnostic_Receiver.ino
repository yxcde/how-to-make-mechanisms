// How to Make Mechanisms of Control - UdK Berlin Summer 2026 - Karsten Schuhl
/// The Diagnostic Receiver (LED Blink)

// Please install OSC library by Adrian Freed for this code to work on your Pico 2W MCU

#include <WiFi.h>
#include <WiFiUdp.h>
#include <OSCMessage.h>

// --- NETWORK CREDENTIALS ---
const char* ssid = "GL-SFT1200-0a9";    // this needs to be the name of your network router
const char* password = "goodlife";      // this is the password for your wifi connection

// --- LISTENING PORT ---
const unsigned int localPort = 8000; 

WiFiUDP Udp;

void setup() {
  Serial.begin(115200);
  
  // Initialize the onboard LED
  pinMode(LED_BUILTIN, OUTPUT);
  
  // Quick startup blink to prove the physical LED works
  digitalWrite(LED_BUILTIN, HIGH);
  delay(500);
  digitalWrite(LED_BUILTIN, LOW);
  
  delay(2000); // Give Serial monitor time to open

  // 1. Connect to WiFi
  Serial.print("Connecting to WiFi: ");
  Serial.println(ssid);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected!");
  Serial.print("My IP address: ");
  Serial.println(WiFi.localIP());

  // 2. Start listening for incoming UDP packets
  Udp.begin(localPort);
  Serial.printf("Diagnostic Ear listening at IP %s, UDP port %d\n", WiFi.localIP().toString().c_str(), localPort);
}

void loop() {
  // Create an empty message to hold incoming data
  OSCMessage msg;
  int size = Udp.parsePacket();

  // Check if a packet has arrived
  if (size > 0) {
    while (size--) {
      // Read the data byte by byte
      msg.fill(Udp.read());
    }
    
    // If it is a valid OSC message (no formatting errors)
    if (!msg.hasError()) {
      
      // BLINK THE ONBOARD LED!
      digitalWrite(LED_BUILTIN, HIGH);
      delay(50); // A rapid, 50-millisecond flash
      digitalWrite(LED_BUILTIN, LOW);
      
      // Print confirmation to the monitor
      Serial.println(">>> OSC Packet Received! Blink triggered.");
    }
  }
}