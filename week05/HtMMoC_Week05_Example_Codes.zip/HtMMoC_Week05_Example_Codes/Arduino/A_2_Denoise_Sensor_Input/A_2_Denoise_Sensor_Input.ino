// Mechanisms of Control - UdK Berlin Winter Semester 2025/26 - Karsten Schuhl
// Adapted for Raspberry Pi Pico 2W - Threshold for sensor input to keep motor from wiggling

// TASK: replace the potentiometer with another sensor (distance or similar) and 
// calibrate the threshold and mapping so that they work well

#include <SpeedyStepper.h> 

SpeedyStepper stepper;              // initialise the SpeedyStepper library

// Pin assignments for Raspberry Pi Pico 2W
const int sensorPin = 26;          // A0 on the Pico corresponds to GP26
const int stepPin = 14;            // GP14
const int dirPin = 15;             // GP15

// Variables for checks and functions
const int threshold = 10;          // Minimum change in steps to trigger motion
const int maxSteps = 1600;         // Maximum number of steps for one motion
long lastTargetPosition = -9999;   // Store last accepted position (set low to guarantee first move)

void setup() {
  Serial.begin(115200);            // Standard baud rate for Pico over USB
  analogReadResolution(12);        // Unlock the Pico's 12-bit ADC (0-4095)
  
  stepper.connectToPins(stepPin, dirPin); 
  stepper.setSpeedInStepsPerSecond(200);                  // set the maximum speed
  stepper.setAccelerationInStepsPerSecondPerSecond(1000); // set maximum acceleration
}

void loop() {
  int sensorValue = analogRead(sensorPin); // read the generic sensor 
  
  // Map the 12-bit sensor values (0-4095) to steps
  long targetPosition = map(sensorValue, 0, 4095, 0, maxSteps); 

  // Check if the difference between the new targetPosition and the last one exceeds the threshold
  if (abs(targetPosition - lastTargetPosition) >= threshold) {
    stepper.moveToPositionInSteps(targetPosition);
    lastTargetPosition = targetPosition;
    
    // Printing to the serial monitor only when a move is triggered keeps it readable
    Serial.print("Moving to step: ");
    Serial.println(targetPosition);
  }
}