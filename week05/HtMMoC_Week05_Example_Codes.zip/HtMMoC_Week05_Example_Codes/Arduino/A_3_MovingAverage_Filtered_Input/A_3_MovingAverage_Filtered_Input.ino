// How to Make Mechanisms of Control - UdK Berlin Summer Semester 2026 - Karsten Schuhl
// Adapted for Raspberry Pi Pico 2W - Stepper Motor with EMA Smoothing & Threshold

// TASK: replace the potentiometer with another sensor (distance or similar) and 
// calibrate the threshold and mapping so that they work well

#include <SpeedyStepper.h> 

SpeedyStepper stepper;

// Pin assignments for Raspberry Pi Pico 2W
const int sensorPin = 26;          // A0 on the Pico
const int stepPin = 14;            // GP14
const int dirPin = 15;             // GP15

// --- Smoothing Variables ---
// Alpha value between 0.0 (infinite delay) and 1.0 (no smoothing)
const float alpha = 0.1; 
float filteredSensorValue = 0.0;   // Store as a float for math precision

// --- Threshold Variables ---
const int threshold = 10;          // Minimum change in steps to trigger motion
const int maxSteps = 1600;         // Maximum number of steps for one motion
long lastTargetPosition = -9999;   // Start out of bounds to guarantee first move

void setup() {
  Serial.begin(115200);            
  analogReadResolution(12);        // Pico's 12-bit ADC (0-4095)
  
  stepper.connectToPins(stepPin, dirPin); 
  stepper.setSpeedInStepsPerSecond(200);                  
  stepper.setAccelerationInStepsPerSecondPerSecond(1000); 
  
  // Prime the filter with the initial reading so the math doesn't start at 0
  filteredSensorValue = analogRead(sensorPin);
}

void loop() {
  // 1. Read the raw, noisy sensor
  int rawSensorValue = analogRead(sensorPin); 
  
  // 2. Apply the Exponential Moving Average math
  filteredSensorValue = (alpha * rawSensorValue) + ((1.0 - alpha) * filteredSensorValue);
  
  // 3. Map the SMOOTHED 12-bit value to the stepper's step range
  // We cast the float back to an int/long here because map() requires whole numbers
  long targetPosition = map((long)filteredSensorValue, 0, 4095, 0, maxSteps); 

  // 4. Apply the deadband threshold
  if (abs(targetPosition - lastTargetPosition) >= threshold) {
    stepper.moveToPositionInSteps(targetPosition);
    lastTargetPosition = targetPosition;
    
    // Print telemetry only when moving to keep the serial monitor clean
    Serial.print("Raw ADC: ");
    Serial.print(rawSensorValue);
    Serial.print("\tFiltered ADC: ");
    Serial.print((int)filteredSensorValue);
    Serial.print("\tMoving to Step: ");
    Serial.println(targetPosition);
  }
}