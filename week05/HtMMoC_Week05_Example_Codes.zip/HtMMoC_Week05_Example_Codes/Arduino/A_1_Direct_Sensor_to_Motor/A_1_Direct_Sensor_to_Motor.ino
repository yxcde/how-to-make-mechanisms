// How to Make Mechanisms of Control - UdK Berlin Summer Semester 2026 - Karsten Schuhl
// Adapted for Raspberry Pi Pico 2W - Potentiometer to Stepper Motor Position

// ! please install the SpeedyStepper library before use !

#include <SpeedyStepper.h>

SpeedyStepper stepper;

// Pin assignments for Raspberry Pi Pico 2W
const int stepPin = 14; // GP14 (You can use almost any digital pin)
const int dirPin = 15;  // GP15 (You can use almost any digital pin)
const int potPin = 26;  // A0 on the Pico corresponds to GP26

void setup() {
  // Unlock the Pico's higher resolution 12-bit ADC (0-4095)
  analogReadResolution(12);
  
  stepper.connectToPins(stepPin, dirPin);
  stepper.setSpeedInStepsPerSecond(200);
  stepper.setAccelerationInStepsPerSecondPerSecond(1000);
}

void loop() {
  // Read the potentiometer value (now ranging from 0 to 4095)
  int sensorValue = analogRead(potPin);
  
  // Map the 12-bit sensor value to the 1600 steps of your stepper motor
  long targetPosition = map(sensorValue, 0, 4095, 0, 1600); // adjust maximum motion range here

  stepper.moveToPositionInSteps(targetPosition); // execute the motion to the target point
}